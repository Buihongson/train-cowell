// function classCity(name, location) {
//     this.name = name;
//     this.location = location;
//     this.buildAction;

//     this.build = function(action) {
//         this.buildAction = action;
//         console.log(action)
//     }

//     this.tax = function() {
//         this.build(this.buildAction);
//         console.log(this.location + 'Get TAX');
//     }

//     this.chongThamNhung = function() {

//     }
// }

// var DaNang = new classCity('Da Nang', 'Mien Trung');
// var HaNoi = new classCity('Ha Noi', 'Mien Bac');

// DaNang.build('Toa nha van phong');
// DaNang.tax();



// class for init Form
function classForm(id) {
    this.id = id;
    this.form;
    this.row;

    this.init = function() {
        this.form = document.getElementById(this.id);
        return this.form;
    }

    this.createRow = function() {
        this.row = document.createElement('div');
    }

    this.append = function(label, input) {
        this.createRow();
        this.row.appendChild(label);
        this.row.appendChild(input);
        this.form.appendChild(this.row);
    }
}

// class for init Input
function classInput(name, value) {
    this.name = name;
    this.label = name;
    this.value = value;
    this.type = 'text';
    this.el;

    this.build = function() {
        switch (this.type) {
            case 'button':
                break;
            case 'radio':
                break;
            default: // input text
                this.el = document.createElement('input');
                this.createAttr('type', 'text');
                this.createAttr('value', this.value);
        }
        return this.el;
    }
    this.buildLabel = function() {
        var elLabel = document.createElement('label');
        elLabel.innerText = this.label;
        return elLabel;
    }

    this.createAttr = function(attrName, attrValue) {
        var att = document.createAttribute(attrName);
        att.value = attrValue;
        this.el.setAttributeNode(att);  
    }
}

// init form
var form = new classForm('form');
form.init();

// handle button
var btn = document.getElementById('btnAdd');
btn.addEventListener("click", function(){
    var elName = document.getElementById('editorName');
    var elValue = document.getElementById('editorValue');
    var input = new classInput(elName.value, elValue.value);
    form.append(input.buildLabel(), input.build());
});


